package com.dio.padraoprojetos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PadraoProjetosApplication {

	public static void main(String[] args) {
		SpringApplication.run(PadraoProjetosApplication.class, args);
	}

}
