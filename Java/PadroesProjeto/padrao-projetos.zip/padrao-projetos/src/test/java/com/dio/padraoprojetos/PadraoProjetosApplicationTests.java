package com.dio.padraoprojetos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PadraoProjetosApplicationTests {

	@Test
	void contextLoads() {
	}

}
